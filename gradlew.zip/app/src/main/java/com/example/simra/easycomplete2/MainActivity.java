package com.example.simra.easycomplete2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static ArrayList<ArrayList<String>> namesAndInfo;
    public static ArrayList<ArrayList<String>> getNamesAndInfo()
    {
        return namesAndInfo;
    }
    public static ArrayList<String> infoNeeded;
    public static ArrayList<String> getInfoNeeded(){return infoNeeded;}
    public static String nameToBeUsed;
    public static ArrayList<String> justNames;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        infoNeeded = new ArrayList<String>();
        namesAndInfo = new ArrayList<ArrayList<String>>();
        setContentView(R.layout.activity_main);
        nameToBeUsed = "";
        justNames = new ArrayList<String>();

    }
    public void makeForm(View v)
    {
        Intent intent = new Intent(this, FillInInformation.class);
        startActivity(intent);
    }
    public void sendMessage(View v)
    {
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        startActivity(intent);
    }
    public void showPeople(View v)
    {
        Intent intent = new Intent(this, ShowPeople.class);
        startActivity(intent);
    }
    public void goToScanner(View v)
    {
        Intent intent = new Intent(this, PreQRScanner.class);
        startActivity(intent);
    }
    public void makeQRCode(View v)
    {
        Intent intent = new Intent(this, QRGenerator.class);
        startActivity(intent);
    }
}
